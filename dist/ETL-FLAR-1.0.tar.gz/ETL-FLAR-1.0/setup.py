from setuptools import setup

setup(
    name="ETL-FLAR",
    version="1.0",
    description="""
    ETL-FLAR
    Es un paquete diseñado para el proceso de extracción, transformación y cargar
    del Sistema de Información Económica del Fondo Lationamericano de Reservas
    """,
    author="Miguel",
    author_email="",
    url="",
    packages= ["ARG"]
)