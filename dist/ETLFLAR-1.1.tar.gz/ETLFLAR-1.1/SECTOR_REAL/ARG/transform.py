import pandas as pd 
import numpy as np 

def clean(filename,extract_path,save_path):
    df = pd.read_excel(extract_path+f"/{filename}", sheet_name="cuadro 4")
    
    header = df.iloc[3,1:].dropna()
    total_mask = header.str.lower().str.contains("total")
    total_ci = header[total_mask].index #contiene los índices de las columnas que contienen "total" para ser eliminadas

    df_wo_total = df.drop(total_ci, axis=1)
    pib = df_wo_total.iloc[5,1:].dropna()/4 #argentina publica el pib acumulado anual, por ende cada trimestre se divide entre 4 
    pib = pib.dropna() #se eliminan los valores nulos

    date_range = pd.date_range(start="30-01-2004", freq="Q", periods=len(pib))
    if len(date_range) == len(pib):
        pib = pd.DataFrame(pib).applymap(lambda x: float(x)).set_index(date_range)
        pib.columns = ["ARG"]
        pib = pib.pct_change(4)*100  #Variación Anual 
        pib.to_csv(save_path+"/TRANSFORM/ARG/1.01.1.csv",decimal=',')
    else:
        print("El rango de fecha no coincide con la longitud del indicador")
