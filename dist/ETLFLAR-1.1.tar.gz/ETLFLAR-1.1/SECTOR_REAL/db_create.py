from SECTOR_REAL.db import get_db


def create_table_pib():
    cnxn , cursor = get_db()
    tables = [table.table_name for table in cursor.tables()]

    if 'pib' not in tables:
        ## Create table countries
        PIB_table = """
            CREATE TABLE pib (
                Date  DATETIME NOT NULL,
                ARG numeric(10,5) NULL,
                BOL numeric(10,5) NULL,
                BRA numeric(10,5) NULL,
                CHL numeric(10,5) NULL,
                COL numeric(10,5) NULL,
            );
        """
        with cursor.execute(PIB_table):
            print("PIB table has been created in")

    cursor.close()
    cnxn.close()
