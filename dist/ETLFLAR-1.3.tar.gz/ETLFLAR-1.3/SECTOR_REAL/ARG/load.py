def upload(state):
    return state
    
    