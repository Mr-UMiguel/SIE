from setuptools import setup, find_packages

setup(
    name="ETLFLAR",
    version="1.3",
    description="""
    ETL-FLAR
    Es un paquete diseñado para el proceso de extracción, transformación y cargar
    del Sistema de Información Económica del Fondo Lationamericano de Reservas
    """,
    author="Miguel",
    author_email="",
    url="",
    packages= find_packages(),
)